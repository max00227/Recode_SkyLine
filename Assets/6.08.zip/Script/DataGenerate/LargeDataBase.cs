﻿using System;
namespace test
{
    public partial class LargeDataBase
    {
        public System.Int32 id;

        public System.String name;
        public System.String detail;
    }
}
