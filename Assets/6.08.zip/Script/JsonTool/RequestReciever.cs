﻿using System;
using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

namespace test
{
	public class RequestReciever : MonoBehaviour
	{
		[SerializeField]
		string api;

		[SerializeField]
		bool isWnd = false;

		[SerializeField]
		bool isPost=false;


		[SerializeField]
		MethodElement[] requestElementList;



		public void RecieveReq(string param="", MethodElement element=null){
			if(isWnd){
				if(isPost){

				}
				else{

				}
			}
			else{
				if (param == null)
				{
					return;
				}
				else
				{
					if (requestElementList.Length > 0)
					{
						SendParams(JsonConversionExtensions.readJson(param, requestElementList));
					}
					else{
						if (element == null) {
							return;
						}
						//setParam (JsonConversionExtensions.ConvertType((object)param,element._methodType), element);
					}
				}
			}
		}

		void SendParams(List<object> _params){
			for (int i = 0; i < _params.Count;i++){
				RequestReciever reciever = requestElementList[i].sendGameObject.GetComponent<RequestReciever>();
				if (requestElementList[i].paramFunc!=ParamFuncEnum.Defaut) {
					setParam (JsonConversionExtensions.ConvertType(_params[i],requestElementList[i]._methodType), requestElementList [i]);
				} 
				else {
					reciever.RecieveReq (_params [i].ToString (), requestElementList[i]);
				}
			}
		}

		void setParam(object param , MethodElement element){
			switch (element.paramFunc) {
			case ParamFuncEnum.SetLabel:
				//Debug.Log (param.ToString ());
				element.sendGameObject.GetComponent<Text> ().text = param.ToString ();
				break;

			case ParamFuncEnum.SetCount:
				break;

			case ParamFuncEnum.SetTexture:
				element.sendGameObject.GetComponent<Image> ().overrideSprite = Resources.Load (param.ToString (), typeof(Sprite)) as Sprite;
				;
				break;
			
			case ParamFuncEnum.SetListItem:
				element.sendGameObject.GetComponent<ItemListContainer> ().SetListItem ((List<object>)param); 
				break;

			case ParamFuncEnum.SetActive:
				int parseValue = 0;
				if (Int32.TryParse (param.ToString(), out parseValue)) {
					element.sendGameObject.SetActive (parseValue == 1);
				} else {
					element.sendGameObject.SetActive (false);
				}
				break;
			}
		}
	}
}