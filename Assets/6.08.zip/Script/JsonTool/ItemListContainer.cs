﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemListContainer : MonoBehaviour {

	[SerializeField]
	GameObject listItem;

	[SerializeField]
	test.MethodElement[] requestElementList;

	List<object> itemlist;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void SetListItem(object param){
		itemlist = (List<object>)param;
		if (itemlist.Count > 0) {
			for (int i = 0; i < itemlist.Count; i++) {
				GameObject item = Instantiate (listItem, transform.position, Quaternion.identity);
				item.transform.parent = this.transform;
				item.GetComponent<test.RequestReciever> ().RecieveReq (itemlist [i].ToString ());
			}
		}
	}
}
